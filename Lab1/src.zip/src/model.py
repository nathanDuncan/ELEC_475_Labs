

import torch
import torch.nn.functional as F
import torch.nn as nn


class autoencoderMLP4Layer(nn.Module):

	def __init__(self, N_input=784, N_bottleneck=8, N_output=784):
		#
		#	Your code here ...
		#

	def forward(self, X):
		#
		#	Your code here ...
		#		




